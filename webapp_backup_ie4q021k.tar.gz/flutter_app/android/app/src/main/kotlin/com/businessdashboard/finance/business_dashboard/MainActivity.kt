package com.businessdashboard.finance.business_dashboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
