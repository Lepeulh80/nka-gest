import 'package:hive_flutter/hive_flutter.dart';
import '../models/revenue.dart';
import '../models/expense.dart';
import '../models/client.dart';
import '../models/supplier.dart';

class DatabaseService {
  static const String revenuesBox = 'revenues';
  static const String expensesBox = 'expenses';
  static const String clientsBox = 'clients';
  static const String suppliersBox = 'suppliers';

  static Future<void> init() async {
    await Hive.initFlutter();

    // Open boxes with dynamic type
    await Hive.openBox(revenuesBox);
    await Hive.openBox(expensesBox);
    await Hive.openBox(clientsBox);
    await Hive.openBox(suppliersBox);
    
    // Initialize sample data if boxes are empty
    await _initializeSampleData();
  }

  static Future<void> _initializeSampleData() async {
    final revenuesBoxRef = Hive.box(revenuesBox);
    final expensesBoxRef = Hive.box(expensesBox);
    final clientsBoxRef = Hive.box(clientsBox);
    final suppliersBoxRef = Hive.box(suppliersBox);

    if (clientsBoxRef.isEmpty) {
      final sampleClients = [
        Client(
          id: 'client_001',
          name: 'Sophie Martin',
          email: 'sophie.martin@email.com',
          phone: '+33 6 12 34 56 78',
          company: 'Tech Solutions SARL',
          address: '15 Avenue des Champs, 75008 Paris',
          createdAt: DateTime.now().subtract(const Duration(days: 120)),
          totalRevenue: 45000.0,
        ),
        Client(
          id: 'client_002',
          name: 'Jean Dupont',
          email: 'j.dupont@entreprise.fr',
          phone: '+33 6 23 45 67 89',
          company: 'Dupont & Associés',
          address: '8 Rue de la République, 69002 Lyon',
          createdAt: DateTime.now().subtract(const Duration(days: 90)),
          totalRevenue: 32000.0,
        ),
        Client(
          id: 'client_003',
          name: 'Marie Dubois',
          email: 'marie.dubois@startup.io',
          phone: '+33 7 34 56 78 90',
          company: 'Innovation Lab',
          address: '42 Boulevard Haussmann, 75009 Paris',
          createdAt: DateTime.now().subtract(const Duration(days: 60)),
          totalRevenue: 28000.0,
        ),
      ];

      for (var client in sampleClients) {
        await clientsBoxRef.add(client.toMap());
      }
    }

    if (suppliersBoxRef.isEmpty) {
      final sampleSuppliers = [
        Supplier(
          id: 'supplier_001',
          name: 'Bureau Express',
          email: 'contact@bureau-express.fr',
          phone: '+33 1 40 50 60 70',
          company: 'Bureau Express SAS',
          address: '25 Rue du Commerce, 75015 Paris',
          createdAt: DateTime.now().subtract(const Duration(days: 180)),
          totalExpenses: 12000.0,
        ),
        Supplier(
          id: 'supplier_002',
          name: 'Tech Services',
          email: 'info@techservices.fr',
          phone: '+33 1 45 55 65 75',
          company: 'Tech Services France',
          address: '10 Avenue de la Grande Armée, 75017 Paris',
          createdAt: DateTime.now().subtract(const Duration(days: 150)),
          totalExpenses: 18000.0,
        ),
      ];

      for (var supplier in sampleSuppliers) {
        await suppliersBoxRef.add(supplier.toMap());
      }
    }

    if (revenuesBoxRef.isEmpty) {
      final now = DateTime.now();
      final sampleRevenues = [
        Revenue(
          id: 'rev_001',
          description: 'Prestation de conseil stratégique',
          amount: 15000.0,
          date: DateTime(now.year, now.month, 5),
          category: 'Conseil',
          clientId: 'client_001',
          invoiceNumber: 'INV-2025-001',
        ),
        Revenue(
          id: 'rev_002',
          description: 'Développement application mobile',
          amount: 12000.0,
          date: DateTime(now.year, now.month, 12),
          category: 'Développement',
          clientId: 'client_002',
          invoiceNumber: 'INV-2025-002',
        ),
        Revenue(
          id: 'rev_003',
          description: 'Formation équipe technique',
          amount: 8000.0,
          date: DateTime(now.year, now.month, 18),
          category: 'Formation',
          clientId: 'client_003',
          invoiceNumber: 'INV-2025-003',
        ),
      ];

      for (var revenue in sampleRevenues) {
        await revenuesBoxRef.add(revenue.toMap());
      }
    }

    if (expensesBoxRef.isEmpty) {
      final now = DateTime.now();
      final sampleExpenses = [
        Expense(
          id: 'exp_001',
          description: 'Matériel informatique',
          amount: 2500.0,
          date: DateTime(now.year, now.month, 3),
          category: 'Équipement',
          supplierId: 'supplier_001',
          isPaid: true,
        ),
        Expense(
          id: 'exp_002',
          description: 'Abonnement logiciels',
          amount: 1200.0,
          date: DateTime(now.year, now.month, 10),
          category: 'Logiciels',
          supplierId: 'supplier_002',
          isPaid: true,
        ),
        Expense(
          id: 'exp_003',
          description: 'Loyer bureau',
          amount: 3000.0,
          date: DateTime(now.year, now.month, 1),
          category: 'Loyer',
          isPaid: true,
        ),
      ];

      for (var expense in sampleExpenses) {
        await expensesBoxRef.add(expense.toMap());
      }
    }
  }

  // Revenue operations
  static Box getRevenuesBox() => Hive.box(revenuesBox);
  
  static Future<void> addRevenue(Revenue revenue) async {
    await getRevenuesBox().add(revenue.toMap());
  }

  static List<Revenue> getAllRevenues() {
    return getRevenuesBox()
        .values
        .map((data) => Revenue.fromMap(Map<String, dynamic>.from(data as Map)))
        .toList();
  }

  // Expense operations
  static Box getExpensesBox() => Hive.box(expensesBox);
  
  static Future<void> addExpense(Expense expense) async {
    await getExpensesBox().add(expense.toMap());
  }

  static List<Expense> getAllExpenses() {
    return getExpensesBox()
        .values
        .map((data) => Expense.fromMap(Map<String, dynamic>.from(data as Map)))
        .toList();
  }

  // Client operations
  static Box getClientsBox() => Hive.box(clientsBox);
  
  static Future<void> addClient(Client client) async {
    await getClientsBox().add(client.toMap());
  }

  static List<Client> getAllClients() {
    return getClientsBox()
        .values
        .map((data) => Client.fromMap(Map<String, dynamic>.from(data as Map)))
        .toList();
  }

  // Supplier operations
  static Box getSuppliersBox() => Hive.box(suppliersBox);
  
  static Future<void> addSupplier(Supplier supplier) async {
    await getSuppliersBox().add(supplier.toMap());
  }

  static List<Supplier> getAllSuppliers() {
    return getSuppliersBox()
        .values
        .map((data) => Supplier.fromMap(Map<String, dynamic>.from(data as Map)))
        .toList();
  }

  // Statistics
  static double getTotalRevenues() {
    return getAllRevenues().fold(0.0, (sum, revenue) => sum + revenue.amount);
  }

  static double getTotalExpenses() {
    return getAllExpenses().fold(0.0, (sum, expense) => sum + expense.amount);
  }

  static double getBalance() {
    return getTotalRevenues() - getTotalExpenses();
  }

  static Map<String, double> getRevenuesByCategory() {
    final revenues = getAllRevenues();
    final Map<String, double> categoryTotals = {};
    
    for (var revenue in revenues) {
      categoryTotals[revenue.category] = 
          (categoryTotals[revenue.category] ?? 0.0) + revenue.amount;
    }
    
    return categoryTotals;
  }

  static Map<String, double> getExpensesByCategory() {
    final expenses = getAllExpenses();
    final Map<String, double> categoryTotals = {};
    
    for (var expense in expenses) {
      categoryTotals[expense.category] = 
          (categoryTotals[expense.category] ?? 0.0) + expense.amount;
    }
    
    return categoryTotals;
  }
}
