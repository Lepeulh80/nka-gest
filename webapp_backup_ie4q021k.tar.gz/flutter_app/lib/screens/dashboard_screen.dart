import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/database_service.dart';
import 'revenues_screen.dart';
import 'expenses_screen.dart';
import 'planning_screen.dart';
import 'reports_screen.dart';
import 'charts_screen.dart';
import 'invoices_screen.dart';
import 'clients_screen.dart';
import 'suppliers_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  double totalRevenues = 0.0;
  double totalExpenses = 0.0;
  double balance = 0.0;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  void _loadStats() {
    setState(() {
      totalRevenues = DatabaseService.getTotalRevenues();
      totalExpenses = DatabaseService.getTotalExpenses();
      balance = DatabaseService.getBalance();
    });
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final monthName = DateFormat.MMMM('fr_FR').format(now);
    final year = now.year;
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chef d\'entreprise'),
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {},
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Dashboard grid with 8 features
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                children: [
                  _buildDashboardCard(
                    title: 'Revenu',
                    icon: Icons.attach_money,
                    iconColor: Colors.green,
                    iconBgColor: Colors.green.withValues(alpha: 0.1),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const RevenuesScreen(),
                        ),
                      ).then((_) => _loadStats());
                    },
                  ),
                  _buildDashboardCard(
                    title: 'Dépense',
                    icon: Icons.shopping_cart,
                    iconColor: Colors.red,
                    iconBgColor: Colors.red.withValues(alpha: 0.1),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ExpensesScreen(),
                        ),
                      ).then((_) => _loadStats());
                    },
                  ),
                  _buildDashboardCard(
                    title: 'Planification',
                    icon: Icons.calendar_today,
                    iconColor: Colors.orange,
                    iconBgColor: Colors.orange.withValues(alpha: 0.1),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const PlanningScreen(),
                        ),
                      );
                    },
                  ),
                  _buildDashboardCard(
                    title: 'Rapport de contrôle\nfinancier',
                    icon: Icons.assessment,
                    iconColor: Colors.red,
                    iconBgColor: Colors.red.withValues(alpha: 0.1),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ReportsScreen(),
                        ),
                      );
                    },
                  ),
                  _buildDashboardCard(
                    title: 'Graphes',
                    icon: Icons.pie_chart,
                    iconColor: Colors.blue,
                    iconBgColor: Colors.blue.withValues(alpha: 0.1),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ChartsScreen(),
                        ),
                      );
                    },
                  ),
                  _buildDashboardCard(
                    title: 'Envoyer une facture',
                    icon: Icons.receipt_long,
                    iconColor: Colors.blue,
                    iconBgColor: Colors.blue.withValues(alpha: 0.1),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const InvoicesScreen(),
                        ),
                      );
                    },
                  ),
                  _buildDashboardCard(
                    title: 'Liste des clients',
                    icon: Icons.people,
                    iconColor: Colors.teal,
                    iconBgColor: Colors.teal.withValues(alpha: 0.1),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const ClientsScreen(),
                        ),
                      );
                    },
                  ),
                  _buildDashboardCard(
                    title: 'Liste des fournisseurs',
                    icon: Icons.business,
                    iconColor: Colors.blue,
                    iconBgColor: Colors.blue.withValues(alpha: 0.1),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SuppliersScreen(),
                        ),
                      );
                    },
                  ),
                ],
              ),
              const SizedBox(height: 24),
              
              // Financial summary
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$monthName $year',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildStatColumn(
                          'Revenu',
                          NumberFormat.currency(
                            locale: 'fr_FR',
                            symbol: '\$',
                            decimalDigits: 2,
                          ).format(totalRevenues),
                          Colors.green,
                        ),
                        _buildStatColumn(
                          'Dépenses',
                          NumberFormat.currency(
                            locale: 'fr_FR',
                            symbol: '\$',
                            decimalDigits: 2,
                          ).format(totalExpenses),
                          Colors.red,
                        ),
                        _buildStatColumn(
                          'Balance',
                          NumberFormat.currency(
                            locale: 'fr_FR',
                            symbol: '\$',
                            decimalDigits: 2,
                          ).format(balance),
                          balance >= 0 ? Colors.green : Colors.red,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDashboardCard({
    required String title,
    required IconData icon,
    required Color iconColor,
    required Color iconBgColor,
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: iconBgColor,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  icon,
                  size: 32,
                  color: iconColor,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatColumn(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
