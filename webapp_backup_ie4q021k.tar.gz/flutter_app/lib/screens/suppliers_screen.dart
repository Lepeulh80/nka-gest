import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/supplier.dart';
import '../services/database_service.dart';

class SuppliersScreen extends StatefulWidget {
  const SuppliersScreen({super.key});

  @override
  State<SuppliersScreen> createState() => _SuppliersScreenState();
}

class _SuppliersScreenState extends State<SuppliersScreen> {
  List<Supplier> suppliers = [];

  @override
  void initState() {
    super.initState();
    _loadSuppliers();
  }

  void _loadSuppliers() {
    setState(() {
      suppliers = DatabaseService.getAllSuppliers();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Liste des fournisseurs'),
      ),
      body: suppliers.isEmpty
          ? const Center(child: Text('Aucun fournisseur'))
          : ListView.builder(
              itemCount: suppliers.length,
              itemBuilder: (context, index) {
                final supplier = suppliers[index];
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.blue.withValues(alpha: 0.1),
                      child: const Icon(Icons.business, color: Colors.blue),
                    ),
                    title: Text(supplier.name),
                    subtitle: Text('${supplier.email}\n${supplier.phone}'),
                    trailing: Text(
                      NumberFormat.currency(
                        locale: 'fr_FR',
                        symbol: '\$',
                        decimalDigits: 0,
                      ).format(supplier.totalExpenses),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
