import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/database_service.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final totalRevenues = DatabaseService.getTotalRevenues();
    final totalExpenses = DatabaseService.getTotalExpenses();
    final balance = DatabaseService.getBalance();
    final revenues = DatabaseService.getAllRevenues();
    final expenses = DatabaseService.getAllExpenses();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Rapport de contrôle financier'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text(
                      'Résumé financier',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    _buildStatRow('Total des revenus', totalRevenues, Colors.green),
                    const Divider(),
                    _buildStatRow('Total des dépenses', totalExpenses, Colors.red),
                    const Divider(),
                    _buildStatRow(
                      'Balance',
                      balance,
                      balance >= 0 ? Colors.green : Colors.red,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Statistiques',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Card(
              child: ListTile(
                leading: const Icon(Icons.trending_up, color: Colors.green),
                title: const Text('Nombre de revenus'),
                trailing: Text(
                  revenues.length.toString(),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.trending_down, color: Colors.red),
                title: const Text('Nombre de dépenses'),
                trailing: Text(
                  expenses.length.toString(),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.calculate, color: Colors.blue),
                title: const Text('Revenu moyen'),
                trailing: Text(
                  NumberFormat.currency(
                    locale: 'fr_FR',
                    symbol: '\$',
                    decimalDigits: 0,
                  ).format(revenues.isEmpty ? 0 : totalRevenues / revenues.length),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.calculate, color: Colors.orange),
                title: const Text('Dépense moyenne'),
                trailing: Text(
                  NumberFormat.currency(
                    locale: 'fr_FR',
                    symbol: '\$',
                    decimalDigits: 0,
                  ).format(expenses.isEmpty ? 0 : totalExpenses / expenses.length),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, double value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 16),
          ),
          Text(
            NumberFormat.currency(
              locale: 'fr_FR',
              symbol: '\$',
              decimalDigits: 2,
            ).format(value),
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
