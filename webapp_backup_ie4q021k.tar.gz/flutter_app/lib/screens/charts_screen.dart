import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/database_service.dart';

class ChartsScreen extends StatefulWidget {
  const ChartsScreen({super.key});

  @override
  State<ChartsScreen> createState() => _ChartsScreenState();
}

class _ChartsScreenState extends State<ChartsScreen> {
  int touchedIndex = -1;

  @override
  Widget build(BuildContext context) {
    final revenuesByCategory = DatabaseService.getRevenuesByCategory();
    final expensesByCategory = DatabaseService.getExpensesByCategory();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Graphes'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Revenus par catégorie',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            if (revenuesByCategory.isNotEmpty)
              SizedBox(
                height: 250,
                child: PieChart(
                  PieChartData(
                    sections: _createRevenueSections(revenuesByCategory),
                    centerSpaceRadius: 40,
                    sectionsSpace: 2,
                  ),
                ),
              )
            else
              const Center(child: Text('Aucune donnée de revenus')),
            const SizedBox(height: 40),
            const Text(
              'Dépenses par catégorie',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            if (expensesByCategory.isNotEmpty)
              SizedBox(
                height: 250,
                child: PieChart(
                  PieChartData(
                    sections: _createExpenseSections(expensesByCategory),
                    centerSpaceRadius: 40,
                    sectionsSpace: 2,
                  ),
                ),
              )
            else
              const Center(child: Text('Aucune donnée de dépenses')),
          ],
        ),
      ),
    );
  }

  List<PieChartSectionData> _createRevenueSections(Map<String, double> data) {
    final colors = [
      Colors.green,
      Colors.blue,
      Colors.orange,
      Colors.purple,
      Colors.teal,
    ];
    
    final total = data.values.fold<double>(0, (sum, value) => sum + value);
    int index = 0;
    
    return data.entries.map((entry) {
      final percentage = (entry.value / total * 100).toStringAsFixed(1);
      final color = colors[index % colors.length];
      index++;
      
      return PieChartSectionData(
        value: entry.value,
        title: '$percentage%',
        color: color,
        radius: 100,
        titleStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      );
    }).toList();
  }

  List<PieChartSectionData> _createExpenseSections(Map<String, double> data) {
    final colors = [
      Colors.red,
      Colors.deepOrange,
      Colors.amber,
      Colors.pink,
      Colors.brown,
    ];
    
    final total = data.values.fold<double>(0, (sum, value) => sum + value);
    int index = 0;
    
    return data.entries.map((entry) {
      final percentage = (entry.value / total * 100).toStringAsFixed(1);
      final color = colors[index % colors.length];
      index++;
      
      return PieChartSectionData(
        value: entry.value,
        title: '$percentage%',
        color: color,
        radius: 100,
        titleStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      );
    }).toList();
  }
}
