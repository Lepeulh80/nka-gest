class Invoice {
  String id;
  String invoiceNumber;
  String clientId;

  DateTime issueDate;
  DateTime dueDate;
  List<InvoiceItem> items;

  double subtotal;
  double taxRate;
  double taxAmount;
  double total;
  String status; // draft, sent, paid, overdue
  String? notes;

  Invoice({
    required this.id,
    required this.invoiceNumber,
    required this.clientId,
    required this.issueDate,
    required this.dueDate,
    required this.items,
    required this.subtotal,
    this.taxRate = 0.0,
    required this.taxAmount,
    required this.total,
    this.status = 'draft',
    this.notes,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'invoiceNumber': invoiceNumber,
      'clientId': clientId,
      'issueDate': issueDate.toIso8601String(),
      'dueDate': dueDate.toIso8601String(),
      'items': items.map((item) => item.toMap()).toList(),
      'subtotal': subtotal,
      'taxRate': taxRate,
      'taxAmount': taxAmount,
      'total': total,
      'status': status,
      'notes': notes,
    };
  }

  factory Invoice.fromMap(Map<String, dynamic> map) {
    return Invoice(
      id: map['id'] as String,
      invoiceNumber: map['invoiceNumber'] as String,
      clientId: map['clientId'] as String,
      issueDate: DateTime.parse(map['issueDate'] as String),
      dueDate: DateTime.parse(map['dueDate'] as String),
      items: (map['items'] as List).map((item) => InvoiceItem.fromMap(item)).toList(),
      subtotal: (map['subtotal'] as num).toDouble(),
      taxRate: (map['taxRate'] as num?)?.toDouble() ?? 0.0,
      taxAmount: (map['taxAmount'] as num).toDouble(),
      total: (map['total'] as num).toDouble(),
      status: map['status'] as String? ?? 'draft',
      notes: map['notes'] as String?,
    );
  }
}

class InvoiceItem {
  String description;
  int quantity;
  double unitPrice;
  double total;

  InvoiceItem({
    required this.description,
    required this.quantity,
    required this.unitPrice,
    required this.total,
  });

  Map<String, dynamic> toMap() {
    return {
      'description': description,
      'quantity': quantity,
      'unitPrice': unitPrice,
      'total': total,
    };
  }

  factory InvoiceItem.fromMap(Map<String, dynamic> map) {
    return InvoiceItem(
      description: map['description'] as String,
      quantity: map['quantity'] as int,
      unitPrice: (map['unitPrice'] as num).toDouble(),
      total: (map['total'] as num).toDouble(),
    );
  }
}
