class Revenue {
  String id;
  String description;
  double amount;
  DateTime date;
  String category;
  String? clientId;
  String? invoiceNumber;

  Revenue({
    required this.id,
    required this.description,
    required this.amount,
    required this.date,
    required this.category,
    this.clientId,
    this.invoiceNumber,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'description': description,
      'amount': amount,
      'date': date.toIso8601String(),
      'category': category,
      'clientId': clientId,
      'invoiceNumber': invoiceNumber,
    };
  }

  factory Revenue.fromMap(Map<String, dynamic> map) {
    return Revenue(
      id: map['id'] as String,
      description: map['description'] as String,
      amount: (map['amount'] as num).toDouble(),
      date: DateTime.parse(map['date'] as String),
      category: map['category'] as String,
      clientId: map['clientId'] as String?,
      invoiceNumber: map['invoiceNumber'] as String?,
    );
  }
}
