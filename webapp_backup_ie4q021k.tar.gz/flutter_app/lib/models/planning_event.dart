class PlanningEvent {
  String id;
  String title;
  String description;

  DateTime startDate;
  DateTime endDate;
  String category; // meeting, deadline, task, reminder
  String? location;
  bool isCompleted;
  String? clientId;

  PlanningEvent({
    required this.id,
    required this.title,
    required this.description,
    required this.startDate,
    required this.endDate,
    required this.category,
    this.location,
    this.isCompleted = false,
    this.clientId,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'category': category,
      'location': location,
      'isCompleted': isCompleted,
      'clientId': clientId,
    };
  }

  factory PlanningEvent.fromMap(Map<String, dynamic> map) {
    return PlanningEvent(
      id: map['id'] as String,
      title: map['title'] as String,
      description: map['description'] as String,
      startDate: DateTime.parse(map['startDate'] as String),
      endDate: DateTime.parse(map['endDate'] as String),
      category: map['category'] as String,
      location: map['location'] as String?,
      isCompleted: map['isCompleted'] as bool? ?? false,
      clientId: map['clientId'] as String?,
    );
  }
}
