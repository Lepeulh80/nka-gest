class Expense {
  String id;
  String description;
  double amount;
  DateTime date;
  String category;
  String? supplierId;
  String? invoiceNumber;
  bool isPaid;

  Expense({
    required this.id,
    required this.description,
    required this.amount,
    required this.date,
    required this.category,
    this.supplierId,
    this.invoiceNumber,
    this.isPaid = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'description': description,
      'amount': amount,
      'date': date.toIso8601String(),
      'category': category,
      'supplierId': supplierId,
      'invoiceNumber': invoiceNumber,
      'isPaid': isPaid,
    };
  }

  factory Expense.fromMap(Map<String, dynamic> map) {
    return Expense(
      id: map['id'] as String,
      description: map['description'] as String,
      amount: (map['amount'] as num).toDouble(),
      date: DateTime.parse(map['date'] as String),
      category: map['category'] as String,
      supplierId: map['supplierId'] as String?,
      invoiceNumber: map['invoiceNumber'] as String?,
      isPaid: map['isPaid'] as bool? ?? false,
    );
  }
}
