class Supplier {
  String id;
  String name;
  String email;
  String phone;
  String? address;
  String? company;
  DateTime createdAt;
  double totalExpenses;

  Supplier({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    this.address,
    this.company,
    required this.createdAt,
    this.totalExpenses = 0.0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'address': address,
      'company': company,
      'createdAt': createdAt.toIso8601String(),
      'totalExpenses': totalExpenses,
    };
  }

  factory Supplier.fromMap(Map<String, dynamic> map) {
    return Supplier(
      id: map['id'] as String,
      name: map['name'] as String,
      email: map['email'] as String,
      phone: map['phone'] as String,
      address: map['address'] as String?,
      company: map['company'] as String?,
      createdAt: DateTime.parse(map['createdAt'] as String),
      totalExpenses: (map['totalExpenses'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
